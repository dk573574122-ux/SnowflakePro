package com.snowflakepro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local, persistent ledger. Signals are append-only; only outcome/exitPrice
 * may transition once from PENDING to WIN/LOSS/TIE.
 */
class SignalLedger(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aurix_signal_ledger_v1", Context.MODE_PRIVATE)
    private val key = "records"

    @Synchronized
    fun all(): List<FrozenSignal> {
        val raw = prefs.getString(key, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    FrozenSignal(
                        id = o.optString("id"),
                        symbol = o.optString("symbol"),
                        candleTime = o.optLong("candleTime"),
                        direction = o.optString("direction"),
                        entryPrice = o.optDouble("entryPrice"),
                        score = o.optInt("score"),
                        expiryBars = o.optInt("expiryBars", 1),
                        reason = o.optString("reason"),
                        outcome = o.optString("outcome", "PENDING"),
                        exitPrice = if (o.isNull("exitPrice")) null else o.optDouble("exitPrice")
                    )
                )
            }
        }
    }

    @Synchronized
    fun addIfNew(signal: FrozenSignal): Boolean {
        val current = all()
        if (current.any { it.id == signal.id }) return false
        save(current + signal)
        return true
    }

    /**
     * Resolves signals using the close of the candle at signal candle time +
     * expiryBars * timeframeSeconds. Only call with completed candles.
     */
    @Synchronized
    fun resolve(symbol: String, closedCandles: List<Candle>, timeframeSeconds: Long = 60L) {
        if (closedCandles.isEmpty()) return
        val updated = all().map { record ->
            if (record.symbol != symbol || record.outcome != "PENDING") return@map record
            val targetTime = record.candleTime + record.expiryBars * timeframeSeconds
            val exit = closedCandles.firstOrNull { it.time >= targetTime } ?: return@map record
            val exitPrice = exit.close.toDouble()
            val result = when {
                kotlin.math.abs(exitPrice - record.entryPrice) < 1e-10 -> "TIE"
                record.direction == "CALL" && exitPrice > record.entryPrice -> "WIN"
                record.direction == "PUT" && exitPrice < record.entryPrice -> "WIN"
                else -> "LOSS"
            }
            record.copy(outcome = result, exitPrice = exitPrice)
        }
        save(updated)
    }

    fun stats(symbol: String? = null): SignalStats {
        val list = all().filter { symbol == null || it.symbol == symbol }
        return SignalStats(
            total = list.size,
            wins = list.count { it.outcome == "WIN" },
            losses = list.count { it.outcome == "LOSS" },
            ties = list.count { it.outcome == "TIE" },
            pending = list.count { it.outcome == "PENDING" }
        )
    }

    @Synchronized
    private fun save(records: List<FrozenSignal>) {
        val arr = JSONArray()
        records.takeLast(2000).forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("symbol", r.symbol)
                put("candleTime", r.candleTime)
                put("direction", r.direction)
                put("entryPrice", r.entryPrice)
                put("score", r.score)
                put("expiryBars", r.expiryBars)
                put("reason", r.reason)
                put("outcome", r.outcome)
                if (r.exitPrice == null) put("exitPrice", JSONObject.NULL) else put("exitPrice", r.exitPrice)
            })
        }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}
