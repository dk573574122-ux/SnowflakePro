package com.snowflakepro

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Deterministic signal engine.
 * It must receive CLOSED candles only. Caller should pass candles.dropLast(1)
 * when the last element is still forming.
 *
 * A signal is identified by its source candle time. Once persisted, never mutate
 * its direction, entry price, score, expiry or timestamp.
 */
data class FrozenSignal(
    val id: String,
    val symbol: String,
    val candleTime: Long,
    val direction: String,
    val entryPrice: Double,
    val score: Int,
    val expiryBars: Int,
    val reason: String,
    val outcome: String = "PENDING",
    val exitPrice: Double? = null
)

data class SignalStats(
    val total: Int,
    val wins: Int,
    val losses: Int,
    val ties: Int,
    val pending: Int
) {
    val winRate: Double
        get() = if (wins + losses == 0) 0.0 else wins * 100.0 / (wins + losses)
}

object ClosedCandleSignalEngine {
    /**
     * Returns at most one signal for the latest candle in [closedCandles].
     * No intrabar values are used. Call only when a new candle has closed.
     */
    fun analyse(symbol: String, closedCandles: List<Candle>): FrozenSignal? {
        if (closedCandles.size < 60) return null
        val c = closedCandles
        val closes = c.map { it.close.toDouble() }

        fun ema(period: Int): Double {
            val k = 2.0 / (period + 1.0)
            var value = closes.take(period).average()
            for (v in closes.drop(period)) value = v * k + value * (1.0 - k)
            return value
        }

        val e9 = ema(9)
        val e21 = ema(21)
        val diffs = closes.zipWithNext { a, b -> b - a }.takeLast(14)
        val gains = diffs.filter { it > 0.0 }.sum()
        val losses = -diffs.filter { it < 0.0 }.sum()
        val rsi = if (losses == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gains / losses)

        val ranges = c.map { (it.high - it.low).toDouble().coerceAtLeast(0.0) }
        val atr = ranges.takeLast(14).average()
        val avgRange = ranges.takeLast(50).average()
        if (avgRange <= 0.0 || atr < avgRange * 0.45 || atr > avgRange * 2.8) return null

        val up = e9 > e21 && rsi in 53.0..67.0
        val down = e9 < e21 && rsi in 33.0..47.0
        if (!up && !down) return null

        val last = c.last()
        val body = abs(last.close.toDouble() - last.open.toDouble())
        if (body < atr * 0.18) return null
        if (up && last.close <= last.open) return null
        if (down && last.close >= last.open) return null

        val upperWick = last.high.toDouble() - max(last.open, last.close).toDouble()
        val lowerWick = min(last.open, last.close).toDouble() - last.low.toDouble()
        if (up && upperWick > body * 1.35) return null
        if (down && lowerWick > body * 1.35) return null

        val strength = abs(e9 - e21) / atr
        if (strength < 0.08) return null

        val score = (55.0 + min(20.0, strength * 18.0) +
            min(15.0, body / atr * 12.0)).toInt().coerceIn(55, 85)
        val expiry = when {
            atr > avgRange * 1.55 -> 1
            strength > 0.30 -> 2
            else -> 3
        }
        val direction = if (up) "CALL" else "PUT"
        val reason = "EMA9/21; RSI=${rsi.toInt()}; ATR filter; candle body/wick confirmed on close"
        return FrozenSignal(
            id = "$symbol-${last.time}-$direction",
            symbol = symbol,
            candleTime = last.time,
            direction = direction,
            entryPrice = last.close.toDouble(),
            score = score,
            expiryBars = expiry,
            reason = reason
        )
    }
}
