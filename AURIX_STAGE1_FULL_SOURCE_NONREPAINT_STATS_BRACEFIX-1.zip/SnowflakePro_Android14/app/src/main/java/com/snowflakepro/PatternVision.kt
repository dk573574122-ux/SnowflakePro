package com.snowflakepro

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * AURIX Pattern Vision - deterministic, explainable first-stage engine.
 * It detects completed/near-completed structures from closed OHLC candles.
 * It does NOT claim to know future prices or produce calibrated probabilities.
 */
data class PatternMark(
    val type: String,
    val startIndex: Int,
    val endIndex: Int,
    val upper: Float,
    val lower: Float,
    val direction: String,
    val quality: Int,
    val explanation: String
)

data class ProjectionCandle(
    val step: Int,
    val open: Float,
    val high: Float,
    val low: Float,
    val close: Float
)

data class PatternProjection(
    val direction: String,
    val confidenceScore: Int,
    val candles: List<ProjectionCandle>,
    val explanation: String
)

object PatternVision {
    private data class Pivot(val index: Int, val price: Float, val high: Boolean)

    fun detect(candles: List<Candle>): List<PatternMark> {
        if (candles.size < 25) return emptyList()
        val data = candles.takeLast(160)
        val pivots = pivots(data)
        val found = mutableListOf<PatternMark>()
        val last = data.last()
        val range = (data.takeLast(30).maxOf { it.high } -
            data.takeLast(30).minOf { it.low }).coerceAtLeast(0.000001f)
        val tolerance = range * 0.075f

        val highs = pivots.filter { it.high }.takeLast(4)
        val lows = pivots.filter { !it.high }.takeLast(4)

        // Double top / double bottom: two confirmed swing points near the same level.
        if (highs.size >= 2) {
            val a = highs[highs.size - 2]; val b = highs.last()
            if (b.index - a.index >= 5 && abs(a.price - b.price) <= tolerance) {
                val valley = data.subList(a.index, b.index + 1).minOf { it.low }
                if (min(a.price, b.price) - valley > tolerance * 1.2f) {
                    found += PatternMark("DOUBLE_TOP", a.index, b.index, max(a.price,b.price),
                        valley, "PUT", 65, "Две вершины близко по цене; подтверждение — пробой линии шеи.")
                }
            }
        }
        if (lows.size >= 2) {
            val a = lows[lows.size - 2]; val b = lows.last()
            if (b.index - a.index >= 5 && abs(a.price - b.price) <= tolerance) {
                val peak = data.subList(a.index, b.index + 1).maxOf { it.high }
                if (peak - max(a.price, b.price) > tolerance * 1.2f) {
                    found += PatternMark("DOUBLE_BOTTOM", a.index, b.index, peak,
                        min(a.price,b.price), "CALL", 65, "Два минимума близко по цене; подтверждение — пробой линии шеи.")
                }
            }
        }

        // Converging swing highs/lows: triangle candidate.
        if (highs.size >= 2 && lows.size >= 2) {
            val hSlope = highs.last().price - highs[highs.size-2].price
            val lSlope = lows.last().price - lows[lows.size-2].price
            val contracting = hSlope < -tolerance * 0.08f && lSlope > tolerance * 0.08f
            val flatTop = abs(hSlope) <= tolerance * 0.12f && lSlope > tolerance * 0.08f
            val flatBottom = abs(lSlope) <= tolerance * 0.12f && hSlope < -tolerance * 0.08f
            if (contracting || flatTop || flatBottom) {
                found += PatternMark("TRIANGLE", min(highs[highs.size-2].index,lows[lows.size-2].index),
                    max(highs.last().index,lows.last().index), highs.last().price, lows.last().price,
                    "NEUTRAL", 55, "Сужение диапазона. Направление не назначается до подтверждённого пробоя.")
            }
        }

        // Channel candidate: similar slopes of recent swing highs and lows.
        if (highs.size >= 2 && lows.size >= 2) {
            val hs = highs.last().price - highs[highs.size-2].price
            val ls = lows.last().price - lows[lows.size-2].price
            if (abs(hs-ls) <= tolerance * 0.35f && abs(hs) > tolerance * 0.05f) {
                val dir = if (hs > 0) "CALL" else "PUT"
                found += PatternMark("CHANNEL", min(highs[highs.size-2].index,lows[lows.size-2].index),
                    data.lastIndex, max(highs.last().price,lows.last().price),
                    min(highs.last().price,lows.last().price), dir, 50,
                    "Параллельное движение границ канала; это описание структуры, не сигнал входа.")
            }
        }

        // Keep only patterns that still overlap the recent price region.
        return found.filter { last.close <= it.upper + range && last.close >= it.lower - range }
            .distinctBy { it.type }
    }

    /**
     * Four OHLC scenario candles. Body and wick proportions are estimated from
     * recent completed candles; projected prices are scenarios, not future facts.
     * The score is a heuristic quality score, NOT a win probability.
     */
    fun project(candles: List<Candle>, pattern: PatternMark?): PatternProjection? {
        if (candles.size < 20) return null
        val recent = candles.takeLast(20)
        val atr = recent.map { it.high - it.low }.average().toFloat().coerceAtLeast(0.000001f)
        val drift = (recent.last().close - recent.first().close) / 19f
        val patternBias = when (pattern?.direction) {
            "CALL" -> 1f
            "PUT" -> -1f
            else -> 0f
        }
        val driftNorm = (drift / atr).coerceIn(-0.35f, 0.35f)
        val bias = if (patternBias == 0f) driftNorm else (driftNorm * 0.55f + patternBias * 0.12f)
        val direction = when {
            bias > 0.035f -> "CALL"
            bias < -0.035f -> "PUT"
            else -> "NEUTRAL"
        }
        val score = (40 + abs(bias) * 80 + (pattern?.quality ?: 0) * 0.15f)
            .toInt().coerceIn(40, 75)

        // Learn typical candle anatomy from completed bars: body and both shadows.
        val avgBody = recent.map { abs(it.close - it.open) }.average().toFloat().coerceAtLeast(atr * 0.08f)
        val avgUpperWick = recent.map { it.high - max(it.open, it.close) }.average().toFloat().coerceAtLeast(atr * 0.04f)
        val avgLowerWick = recent.map { min(it.open, it.close) - it.low }.average().toFloat().coerceAtLeast(atr * 0.04f)
        val bodyBase = (avgBody * 0.78f).coerceIn(atr * 0.10f, atr * 0.62f)
        val upperBase = (avgUpperWick * 0.90f).coerceIn(atr * 0.04f, atr * 0.42f)
        val lowerBase = (avgLowerWick * 0.90f).coerceIn(atr * 0.04f, atr * 0.42f)

        var previousClose = recent.last().close
        val steps = (1..4).map { n ->
            val open = previousClose
            // Momentum is damped farther into the future to avoid an unrealistic straight line.
            val directionalMove = bias * atr * (0.72f / (1f + n * 0.18f))
            val alternatingBody = if (n % 3 == 0) -0.18f else 0.08f
            val body = (bodyBase * (1f + alternatingBody)).coerceAtLeast(atr * 0.06f)
            val bodyOffset = when (direction) {
                "CALL" -> body * 0.28f
                "PUT" -> -body * 0.28f
                else -> if (n % 2 == 0) -body * 0.18f else body * 0.18f
            }
            val close = open + directionalMove + bodyOffset
            val upperWick = upperBase * (if (n % 2 == 0) 1.18f else 0.82f)
            val lowerWick = lowerBase * (if (n % 2 == 0) 0.82f else 1.18f)
            val high = max(open, close) + upperWick
            val low = min(open, close) - lowerWick
            previousClose = close
            ProjectionCandle(n, open, high, low, close)
        }
        return PatternProjection(direction, score, steps,
            "4 расчётные OHLC-свечи: тела и верхние/нижние тени смоделированы по средним пропорциям последних 20 закрытых свечей и затухающему импульсу. Это сценарий, не точные будущие котировки.")
    }

    private fun pivots(c: List<Candle>): List<Pivot> {
        val out = mutableListOf<Pivot>()
        for (i in 2 until c.size - 2) {
            val x = c[i]
            if ((i-2..i+2).all { j -> j == i || x.high >= c[j].high })
                out += Pivot(i, x.high, true)
            if ((i-2..i+2).all { j -> j == i || x.low <= c[j].low })
                out += Pivot(i, x.low, false)
        }
        return out.sortedBy { it.index }
    }
}
