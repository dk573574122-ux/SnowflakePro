package com.snowflakepro

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val Bg=Color(0xFF0B1018); private val Panel=Color(0xFF151E2B); private val Grid=Color(0xFF263244)
private val Green=Color(0xFF20C997); private val Red=Color(0xFFFF647C); private val Muted=Color(0xFF91A0B5); private val White=Color(0xFFEAF0F8); private val Blue=Color(0xFF70A7FF)

data class Candle(val open:Float,val high:Float,val low:Float,val close:Float,val time:Long)
data class Asset(val symbol:String,val name:String,val open:Boolean?)
data class Tick(val symbol:String,val price:Float,val time:Long)
data class Signal(val direction:String,val score:Int,val expiry:Int,val reason:String)
data class BacktestStats(val wins:Int,val losses:Int,val ties:Int){ val total:Int get()=wins+losses; val winRate:Int get()=if(total==0) 0 else (wins*100.0/total).toInt() }

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setContent{ SnowflakeApp() } } }

@Composable fun SnowflakeApp(){
 var apiKey by remember { mutableStateOf("") }; var assets by remember { mutableStateOf<List<Asset>>(emptyList()) }; var selected by remember { mutableStateOf("") }
 var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }; var status by remember { mutableStateOf("Введи новый ключ OTCharts Lite и загрузи каталог Quotex.") }
 var busy by remember { mutableStateOf(false) }; var streamOn by remember { mutableStateOf(false) }; var showMenu by remember { mutableStateOf(false) }
 var lastTick by remember { mutableStateOf("—") }; var tickPrice by remember { mutableStateOf<Float?>(null) }; var streamStop by remember { mutableStateOf<Thread?>(null) }
 var lockedSignal by remember(selected) { mutableStateOf<Signal?>(null) }
 var lockBarsLeft by remember(selected) { mutableIntStateOf(0) }
 var lastClosedBarTime by remember(selected) { mutableLongStateOf(-1L) }
 val closedCandles = remember(candles) { if (candles.size > 1) candles.dropLast(1) else emptyList() }
 LaunchedEffect(closedCandles, selected) {
  val latest = closedCandles.lastOrNull()
  if (latest != null && latest.time != lastClosedBarTime) {
   if (lockedSignal != null) { lockBarsLeft -= 1; if (lockBarsLeft <= 0) { lockedSignal = null; lockBarsLeft = 0 } }
   if (lockedSignal == null) {
    val candidate = analyse(closedCandles)
    if (candidate != null) { lockedSignal = candidate; lockBarsLeft = candidate.expiry }
   }
   lastClosedBarTime = latest.time
  }
 }
 val signal = lockedSignal
 val backtest = remember(candles) { calculateBacktest(candles) }
 val visibleCandles = remember(candles) { candles.takeLast(60) }
 val patternMarks = remember(visibleCandles) { PatternVision.detect(visibleCandles) }
 val patternProjection = remember(visibleCandles, patternMarks) { PatternVision.project(visibleCandles, patternMarks.lastOrNull()) }
 DisposableEffect(Unit){ onDispose { streamStop?.interrupt() } }
 MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Panel,primary=Green,onBackground=White,onSurface=White)) {
  Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){ Column { Column { Text("AURIX",color=Color(0xFFFFC642),fontSize=24.sp,fontWeight=FontWeight.ExtraBold); Text("OPTIONS MANAGER · ELITE PRO",color=White,fontSize=9.sp,fontWeight=FontWeight.Bold); Text("QUOTEX · OTCHARTS LITE · READ ONLY",color=Muted,fontSize=8.sp) }; Image(painterResource(com.snowflakepro.R.drawable.brand_logo),contentDescription="AURIX logo",modifier=Modifier.size(66.dp),contentScale=ContentScale.Fit) }
   OutlinedTextField(value=apiKey,onValueChange={apiKey=it.trim()},modifier=Modifier.fillMaxWidth(),label={Text("Новый ключ OTCharts")},singleLine=true,visualTransformation=PasswordVisualTransformation(),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=White,unfocusedTextColor=White,focusedBorderColor=Blue,unfocusedBorderColor=Grid))
   Button(onClick={ if(apiKey.isBlank()) status="Введи API-ключ." else { busy=true; status="Загружаем доступный каталог Quotex…"; fetchAssets(apiKey){r-> busy=false; r.onSuccess{list->assets=list; if(selected.isBlank()||list.none{it.symbol==selected})selected=list.firstOrNull{it.open!=false}?.symbol?:list.firstOrNull()?.symbol.orEmpty(); status="Каталог получен: ${list.size} инструментов. Выбери до пяти для Live Stream."; if(selected.isNotBlank()) loadCandles(apiKey,selected){cr->cr.onSuccess{candles=it;status="История загружена: ${candles.size} свечей M1."}.onFailure{status="Ошибка истории: ${it.message}"}} }.onFailure{status="Каталог: ${it.message}"} } },enabled=!busy,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF24364C))){Text(if(busy)"Загрузка…" else "Загрузить каталог Quotex")}
   Text(status,color=Muted,fontSize=11.sp)
   Surface(color=Panel,shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text("ИНСТРУМЕНТ",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Box { OutlinedButton(onClick={showMenu=true},modifier=Modifier.fillMaxWidth()){Text(assets.firstOrNull{it.symbol==selected}?.name?:"Выбери инструмент",color=White)}; DropdownMenu(expanded=showMenu,onDismissRequest={showMenu=false}){assets.forEach{a->DropdownMenuItem(text={Text(a.name+if(a.open==false)" · закрыт" else "")},onClick={selected=a.symbol;showMenu=false;busy=true;loadCandles(apiKey,a.symbol){r->busy=false;r.onSuccess{candles=it;status="Загружено ${it.size} свечей: ${a.name}"}.onFailure{status="История: ${it.message}"}}})}} }
    Text("${selected.ifBlank{"—"}} · M1",color=Muted,fontSize=10.sp)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("ГРАФИК M1",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold);Text(if(streamOn)"LIVE" else "ИСТОРИЯ",color=if(streamOn)Green else Blue,fontSize=10.sp)}
    if(candles.isNotEmpty()) CandleChart(visibleCandles,Modifier.fillMaxWidth().height(230.dp), patternMarks, patternProjection) else Text("Нет загруженных свечей. Демонстрационные данные не показываются.",color=Muted,fontSize=12.sp)
    Text("PATTERN VISION · найдено: ${patternMarks.size}",color=Color(0xFFFFC642),fontSize=11.sp,fontWeight=FontWeight.Bold)
    if(patternMarks.isEmpty()) Text("Пока нет подтверждённого графического паттерна.",color=Muted,fontSize=10.sp)
    patternMarks.forEach { mark -> Text("${mark.type} · ${mark.direction} · оценка структуры ${mark.quality}/100\n${mark.explanation}",color=White,fontSize=10.sp) }
    patternProjection?.let { pr -> Text("ПРОЕКЦИЯ 4 OHLC-СВЕЧЕЙ: ${pr.direction} · оценка условий ${pr.confidenceScore}/100",color=if(pr.direction=="CALL")Green else if(pr.direction=="PUT")Red else Muted,fontSize=11.sp,fontWeight=FontWeight.Bold); Text(pr.explanation,color=Muted,fontSize=10.sp) }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Последняя цена",color=Muted,fontSize=11.sp);Text(tickPrice?.toString()?:candles.lastOrNull()?.close?.toString()?:"—",color=White,fontWeight=FontWeight.Bold)}
    Text("Последний тик: $lastTick",color=Muted,fontSize=10.sp)
   }}
   Surface(color=Panel,shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text("АНАЛИЗ СТРАТЕГИИ",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Text(signal?.direction?:"НЕТ СДЕЛКИ",color=if(signal?.direction=="CALL")Green else if(signal?.direction=="PUT")Red else White,fontSize=30.sp,fontWeight=FontWeight.ExtraBold)
    Text(signal?.let{"Оценка условий: ${it.score}/100 · экспирация ${it.expiry} мин"}?:"Недостаточно подтверждений или мало свечей.",color=White,fontSize=13.sp)
    Text(signal?.reason?:"Ожидаем подтверждение EMA 9/21, RSI и ATR на закрытой свече.",color=Muted,fontSize=11.sp)
    Text(if(signal!=null) "TIME FREEZE · сигнал зафиксирован · осталось свечей: $lockBarsLeft" else "TIME FREEZE · нового подтверждённого сигнала нет", color=if(signal!=null) Blue else Muted,fontSize=10.sp)
    Text("Сигнал фиксируется после закрытия свечи и не пересчитывается на каждом тике. Блокировка действует на срок выбранной экспирации.",color=Muted,fontSize=10.sp)
    Divider(color=Grid)
    Text("ИСТОРИЧЕСКАЯ ПРОВЕРКА · M1",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Text("Сделок: ${backtest.total} · победы: ${backtest.wins} · убытки: ${backtest.losses} · ничьи: ${backtest.ties}",color=White,fontSize=11.sp)
    Text(if(backtest.total>0) "Историческая направленная точность: ${backtest.winRate}%" else "Недостаточно исторических сигналов для оценки.",color=if(backtest.winRate>=55 && backtest.total>=30) Green else Muted,fontSize=12.sp,fontWeight=FontWeight.Bold)
    Text("Walk-forward тест по прошлым свечам. Не учитывает выплаты брокера, спред, задержки и проскальзывание; не является гарантией результата.",color=Muted,fontSize=10.sp)
   }}
   Surface(color=Panel,shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text("LIVE STREAM · ДО 5 ИНСТРУМЕНТОВ",color=Muted,fontSize=11.sp,fontWeight=FontWeight.Bold)
    Text("В список потока входят первые пять доступных инструментов из каталога. Поток только читает котировки и не совершает сделки.",color=Muted,fontSize=10.sp)
    Button(onClick={ if(streamOn){streamStop?.interrupt();streamStop=null;streamOn=false;status="Поток остановлен."} else if(apiKey.isBlank()||assets.isEmpty()){status="Сначала введи ключ и загрузи каталог."} else {val symbols=assets.filter{it.open!=false}.take(5).joinToString(","){it.symbol}; if(symbols.isBlank())status="Нет открытых инструментов." else {streamOn=true;status="Подключаем поток: $symbols";streamStop=startStream(apiKey,symbols){t-> main { if(t.symbol==selected){tickPrice=t.price;lastTick=t.time.toString(); candles=applyTick(candles,t)} } } } }},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(streamOn)Color(0xFF59303A) else Color(0xFF16483D))){Text(if(streamOn)"Остановить Live Stream" else "Подключить Live Stream")}
   }}
   Text("Источник: OTCharts, независимый read-only сервис, не официальный API Quotex. Ключ хранится только в текущем состоянии приложения и не записывается в исходный код. При закрытии приложения введи его снова.",color=Muted,fontSize=10.sp)
  }
 }
}

private fun fetchAssets(key:String,done:(Result<List<Asset>>)->Unit){Thread{try{val j=request("/v1/symbols?venue=quotex",key);val a=j.getJSONArray("symbols");val list=buildList{for(i in 0 until a.length()){val x=a.getJSONObject(i);add(Asset(x.getString("symbol"),x.optString("name",x.getString("symbol")),if(x.isNull("open"))null else x.optBoolean("open")))}}; main{done(Result.success(list))}}catch(e:Exception){main{done(Result.failure(e))}}}.start()}
private fun loadCandles(key:String,symbol:String,done:(Result<List<Candle>>)->Unit){Thread{try{val enc=URLEncoder.encode(symbol,"UTF-8");val j=request("/v1/candles?venue=quotex&symbol=$enc&tf=60&limit=360",key);val a=j.getJSONArray("candles");val list=buildList{for(i in 0 until a.length()){val x=a.getJSONObject(i);add(Candle(x.getDouble("open").toFloat(),x.getDouble("high").toFloat(),x.getDouble("low").toFloat(),x.getDouble("close").toFloat(),x.optLong("time")))}};main{done(Result.success(list))}}catch(e:Exception){main{done(Result.failure(e))}}}.start()}
private fun request(path:String,key:String):JSONObject{val c=URL("https://otcharts.com$path").openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("Authorization","Bearer $key");c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","SnowflakePro/2.0 Android");val code=c.responseCode;val body=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw IllegalStateException("HTTP $code: ${body.take(240)}");return JSONObject(body)}
private fun startStream(key:String,symbols:String,onTick:(Tick)->Unit):Thread{val t=Thread{var c:HttpURLConnection?=null;try{val enc=URLEncoder.encode(symbols,"UTF-8");c=URL("https://otcharts.com/v1/stream?venue=quotex&symbol=$enc").openConnection() as HttpURLConnection;c.connectTimeout=20000;c.readTimeout=0;c.setRequestProperty("Authorization","Bearer $key");c.setRequestProperty("Accept","text/event-stream");c.setRequestProperty("Cache-Control","no-cache");c.setRequestProperty("User-Agent","SnowflakePro/2.0 Android");val code=c.responseCode;if(code !in 200..299){val msg=(c.errorStream?:c.inputStream).bufferedReader().use{it.readText()};throw IllegalStateException("Stream HTTP $code: ${msg.take(200)}")};var event="";c.inputStream.bufferedReader().useLines{lines->lines.forEach{line->if(Thread.currentThread().isInterrupted)throw InterruptedException();when{line.startsWith("event:")->event=line.substringAfter(':').trim();line.startsWith("data:")->if(event=="tick"){val j=JSONObject(line.substringAfter(':').trim());onTick(Tick(j.getString("symbol"),j.getDouble("price").toFloat(),j.optLong("time")))}}}}}catch(_:InterruptedException){}catch(_:Exception){}finally{c?.disconnect()}};t.isDaemon=true;t.start();return t}
private fun main(block:()->Unit)=Handler(Looper.getMainLooper()).post(block)
private fun applyTick(old:List<Candle>,tick:Tick):List<Candle>{if(old.isEmpty())return old;val start=(tick.time/60)*60;val last=old.last();return if(last.time==start)old.dropLast(1)+last.copy(high=max(last.high,tick.price),low=min(last.low,tick.price),close=tick.price) else if(start>last.time)old+ Candle(last.close,max(last.close,tick.price),min(last.close,tick.price),tick.price,start) else old}

private fun analyse(c:List<Candle>):Signal? {
 if(c.size<60) return null
 val closes=c.map{it.close.toDouble()}
 fun ema(period:Int):Double { val k=2.0/(period+1.0); var value=closes.take(period).average(); for(v in closes.drop(period)) value=v*k+value*(1.0-k); return value }
 val e9=ema(9); val e21=ema(21)
 val diffs=closes.zipWithNext{a,b->b-a}
 val recent=diffs.takeLast(14); val gains=recent.filter{it>0.0}.sum(); val losses=-recent.filter{it<0.0}.sum()
 val rsi=if(losses==0.0) 100.0 else 100.0-100.0/(1.0+gains/losses)
 val ranges=c.map{(it.high.toDouble()-it.low.toDouble()).coerceAtLeast(0.0)}
 val atr=ranges.takeLast(14).average(); val avgRange=ranges.takeLast(50).average()
 if(avgRange<=0.0 || atr<avgRange*0.45 || atr>avgRange*2.8) return null
 val up=e9>e21 && rsi in 53.0..67.0; val down=e9<e21 && rsi in 33.0..47.0
 if(!up&&!down) return null
 val last=c.last(); val body=abs(last.close.toDouble()-last.open.toDouble())
 if(body<atr*0.18) return null
 if(if(up) last.close<=last.open else last.close>=last.open) return null
 val upperWick=last.high.toDouble()-max(last.open,last.close).toDouble()
 val lowerWick=min(last.open,last.close).toDouble()-last.low.toDouble()
 if(if(up) upperWick>body*1.35 else lowerWick>body*1.35) return null
 val strength=abs(e9-e21)/atr
 if(strength<0.08) return null
 val score=(55.0+min(20.0,strength*18.0)+min(15.0,body/atr*12.0)).toInt().coerceIn(55,85)
 val expiry=when { atr>avgRange*1.55->1; strength>0.30->2; else->3 }
 return Signal(if(up)"CALL" else "PUT",score,expiry,"EMA 9/21, RSI ${rsi.toInt()}, ATR, тело свечи и встречная тень прошли фильтры.")
}

private fun calculateBacktest(c:List<Candle>):BacktestStats {
 if(c.size<90) return BacktestStats(0,0,0)
 var wins=0; var losses=0; var ties=0
 val start=max(60,c.size-300)
 for(i in start until c.size-4) {
  val sig=analyse(c.subList(0,i)) ?: continue
  val entry=c[i].open.toDouble()
  val exitIndex=i+sig.expiry-1
  if(exitIndex>c.lastIndex) continue
  val exit=c[exitIndex].close.toDouble()
  when { abs(exit-entry)<1e-10 -> ties++; sig.direction=="CALL" && exit>entry -> wins++; sig.direction=="PUT" && exit<entry -> wins++; else -> losses++ }
 }
 return BacktestStats(wins,losses,ties)
}



@Composable
private fun CandleChart(data: List<Candle>, modifier: Modifier = Modifier, marks: List<PatternMark> = emptyList(), projection: PatternProjection? = null) {
    Canvas(
        modifier
            .background(Color(0xFF0D1520), RoundedCornerShape(10.dp))
            .padding(5.dp)
    ) {
        if (data.isEmpty()) return@Canvas

        val low = min(data.minOf { it.low }, projection?.candles?.minOfOrNull { it.low } ?: data.minOf { it.low })
        val high = max(data.maxOf { it.high }, projection?.candles?.maxOfOrNull { it.high } ?: data.maxOf { it.high })
        val padding = (high - low) * 0.08f
        val minPrice = low - padding
        val maxPrice = high + padding
        val priceRange = (maxPrice - minPrice).coerceAtLeast(0.000001f)

        fun y(price: Float): Float {
            return size.height - (price - minPrice) / priceRange * size.height
        }

        for (i in 0..4) {
            val yy = size.height * i / 4f
            drawLine(Grid, Offset(0f, yy), Offset(size.width, yy), 1f)
        }

        val slot = size.width / (data.size + 4f)
        data.forEachIndexed { index, candle ->
            val x = slot * (index + 0.5f)
            val candleColor = if (candle.close >= candle.open) Green else Red
            drawLine(candleColor, Offset(x, y(candle.high)), Offset(x, y(candle.low)), 2f)
            val top = y(max(candle.open, candle.close))
            val bottom = y(min(candle.open, candle.close))
            drawRect(
                color = candleColor,
                topLeft = Offset(x - slot * 0.28f, top),
                size = androidx.compose.ui.geometry.Size(
                    slot * 0.56f,
                    max(3f, bottom - top)
                )
            )
        }
        // Pattern boundaries are drawn over the candles; these are detected structures, not entry orders.
        marks.forEach { mark ->
            val left = (mark.startIndex.coerceIn(0, data.lastIndex) + 0.5f) * slot
            val right = (mark.endIndex.coerceIn(0, data.lastIndex) + 0.5f) * slot
            val lineColor = when (mark.direction) { "CALL" -> Green; "PUT" -> Red; else -> Color(0xFFFFC642) }
            drawLine(lineColor, Offset(left, y(mark.upper)), Offset(right, y(mark.upper)), 2f,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 5f)))
            drawLine(lineColor, Offset(left, y(mark.lower)), Offset(right, y(mark.lower)), 2f,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 5f)))
        }
        // Four projected OHLC candles with real bodies and upper/lower shadows.
        // They are visually separated from historical candles by a dashed outline.
        projection?.let { pr ->
            pr.candles.forEach { projected ->
                val x = (data.size + projected.step - 0.5f) * slot
                val bullish = projected.close >= projected.open
                val candleColor = if (bullish) Green else Red
                val wickX = x
                drawLine(candleColor.copy(alpha = 0.95f), Offset(wickX, y(projected.high)), Offset(wickX, y(projected.low)), 2f)
                val bodyTop = y(max(projected.open, projected.close))
                val bodyBottom = y(min(projected.open, projected.close))
                val bodyWidth = slot * 0.56f
                drawRect(
                    color = candleColor.copy(alpha = 0.32f),
                    topLeft = Offset(x - bodyWidth / 2f, bodyTop),
                    size = androidx.compose.ui.geometry.Size(bodyWidth, max(3f, bodyBottom - bodyTop))
                )
                drawRect(
                    color = candleColor,
                    topLeft = Offset(x - bodyWidth / 2f, bodyTop),
                    size = androidx.compose.ui.geometry.Size(bodyWidth, max(3f, bodyBottom - bodyTop)),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(5f, 3f)))
                )
            }
        }
    }
}
