package com.snowflakepro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.min

private val Bg = Color(0xFF0B1018)
private val Panel = Color(0xFF151E2B)
private val Grid = Color(0xFF263244)
private val Green = Color(0xFF20C997)
private val Red = Color(0xFFFF647C)
private val Muted = Color(0xFF91A0B5)
private val White = Color(0xFFEAF0F8)
private val Blue = Color(0xFF70A7FF)

data class Candle(val open: Float, val high: Float, val low: Float, val close: Float, val future: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SnowflakeApp() }
    }
}

@Composable
fun SnowflakeApp() {
    var showForecast by remember { mutableStateOf(true) }
    var showStats by remember { mutableStateOf(true) }
    var refresh by remember { mutableIntStateOf(0) }

    val candles = remember(refresh) { makeDemoCandles() }
    val last = candles.last()
    val bullish = last.close >= last.open
    val score = if (bullish) 74 else 71
    val signal = if (bullish) "CALL" else "PUT"

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green,
        onBackground = White, onSurface = White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("SNOWFLAKE PRO", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("ДЕМО-ВЕРСИЯ · НЕ ПОДКЛЮЧЕНА К QUOTEX", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                Text("❄", color = Blue, fontSize = 30.sp)
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("EUR/USD", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Обычный рынок · M1", color = Muted, fontSize = 12.sp)
                }
                Surface(color = Color(0xFF123B35), shape = RoundedCornerShape(10.dp)) {
                    Text(" DEMO ", color = Green, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ГРАФИК С ПРОГНОЗОМ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("2 СВЕЧИ ВПЕРЁД", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    CandlestickChart(candles, showForecast, Modifier.fillMaxWidth().height(250.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Исторические свечи", color = Muted, fontSize = 10.sp)
                        Text("Прогнозные свечи", color = Blue, fontSize = 10.sp)
                    }
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("ТЕКУЩИЙ СИГНАЛ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("❄ ПРЕДУПРЕЖДЕНИЕ", color = Blue, fontSize = 10.sp)
                    }
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(signal, color = if (bullish) Green else Red, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Score $score/100", color = White, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
                    }
                    Text("Демонстрационный расчёт по синтетическим свечам. Это не торговая рекомендация.", color = Muted, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Прогноз свечи 1", color = Muted, fontSize = 12.sp)
                        Text(if (bullish) "Вверх" else "Вниз", color = if (bullish) Green else Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Прогноз свечи 2", color = Muted, fontSize = 12.sp)
                        Text(if (bullish) "Вверх" else "Вниз", color = if (bullish) Green else Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("НАСТРОЙКИ ОТОБРАЖЕНИЯ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Показывать две прогнозные свечи", color = White, fontSize = 12.sp)
                        Switch(checked = showForecast, onCheckedChange = { showForecast = it })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Показывать статистику", color = White, fontSize = 12.sp)
                        Switch(checked = showStats, onCheckedChange = { showStats = it })
                    }
                    Button(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF24364C))) {
                        Text("Обновить демо-график", color = White)
                    }
                }
            }

            if (showStats) {
                Surface(color = Panel, shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("СТАТИСТИКА", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Stat("Сигналов", "0")
                            Stat("Успешных", "—")
                            Stat("Точность", "Нет данных")
                        }
                        Text("Точность появится после проверки прогнозов на реальных котировках. Сейчас статистика не рассчитывается.", color = Muted, fontSize = 10.sp)
                    }
                }
            }

            Text("Важно: приложение пока работает автономно. Реальные котировки и интеграция с Quotex ещё не подключены. Прогнозные свечи визуально оформлены как обычные, но остаются модельной оценкой.", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

fun makeDemoCandles(): List<Candle> {
    val closes = listOf(1.0841f,1.0844f,1.0842f,1.0847f,1.0849f,1.0846f,1.0850f,1.0852f,1.0851f,1.0855f,1.0853f,1.0857f,1.0859f,1.0856f,1.0860f,1.0862f,1.0861f,1.0864f,1.0863f,1.0866f)
    val base = closes.mapIndexed { i, c ->
        val o = if (i == 0) c - 0.0002f else closes[i-1]
        Candle(o, max(o,c)+0.00015f, min(o,c)-0.00012f, c)
    }
    val last = base.last().close
    val step = if (base.last().close >= base.last().open) 1f else -1f
    val one = last + step * 0.00018f
    val two = one + step * 0.00014f
    return base + listOf(
        Candle(last, max(last,one)+0.00013f, min(last,one)-0.00010f, one, true),
        Candle(one, max(one,two)+0.00012f, min(one,two)-0.00010f, two, true)
    )
}

@Composable
fun CandlestickChart(data: List<Candle>, showForecast: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Color(0xFF0D1520), RoundedCornerShape(10.dp)).padding(4.dp)) {
        val visible = if (showForecast) data else data.filterNot { it.future }
        val minP = visible.minOf { it.low } - 0.00018f
        val maxP = visible.maxOf { it.high } + 0.00018f
        val range = maxP - minP
        fun y(v: Float) = size.height - ((v-minP)/range)*size.height
        for (i in 0..4) {
            val yy = size.height * i / 4f
            drawLine(Grid, Offset(0f, yy), Offset(size.width, yy), 1f)
        }
        val slot = size.width / (if (showForecast) data.size + 1 else data.size + 1).toFloat()
        visible.forEachIndexed { index, c ->
            val x = slot * (index + 1)
            val color = if (c.close >= c.open) Green else Red
            drawLine(color, Offset(x, y(c.high)), Offset(x, y(c.low)), 2f, cap = StrokeCap.Round)
            val top = y(max(c.open,c.close))
            val bottom = y(min(c.open,c.close))
            val h = max(4f, bottom-top)
            drawRect(color, topLeft = Offset(x-slot*0.24f, top), size = androidx.compose.ui.geometry.Size(slot*0.48f, h))
        }
    }
}
