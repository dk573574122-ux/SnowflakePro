package com.snowflakepro

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val Bg=Color(0xFF0B1018); private val Panel=Color(0xFF151E2B); private val Grid=Color(0xFF263244)
private val Green=Color(0xFF20C997); private val Red=Color(0xFFFF647C); private val Muted=Color(0xFF91A0B5); private val White=Color(0xFFEAF0F8); private val Blue=Color(0xFF70A7FF)

data class Candle(val open:Float,val high:Float,val low:Float,val close:Float,val time:Long)
data class Asset(val symbol:String,val name:String,val open:Boolean?)
data class Tick(val symbol:String,val price:Float,val time:Long)
data class Signal(val direction:String,val score:Int,val expiry:Int,val reason:String)
data class BacktestStats(val wins:Int,val losses:Int,val ties:Int){ val total:Int get()=wins+losses; val winRate:Int get()=if(total==0) 0 else (wins*100.0/total).toInt() }

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setContent{ SnowflakeApp() } } }

@Composable fun SnowflakeApp(){
 var apiKey by remember { mutableStateOf("") }; var assets by remember { mutableStateOf<List<Asset>>(emptyList()) }; var selected by remember { mutableStateOf("") }
 var candles by remember { mutableStateOf<List<Candle>>(emptyList()) }; var status by remember { mutableStateOf("Введи новый ключ OTCharts Lite и загрузи каталог Quotex.") }
 var busy by remember { mutableStateOf(false) }; var streamOn by remember { mutableStateOf(false) }; var showMenu by remember { mutableStateOf(false) }
 var lastTick by remember { mutableStateOf("—") }; var tickPrice by remember { mutableStateOf<Float?>(null) }; var streamStop by remember { mutableStateOf<Thread?>(null) }
 var lockedSignal by remember(selected) { mutableStateOf<Signal?>(null) }
 var lockBarsLeft by remember(selected) { mutableIntStateOf(0) }
 var lastClosedBarTime by remember(selected) { mutableLongStateOf(-1L) }
 val closedCandles = remember(candles) { if (candles.size > 1) candles.dropLast(1) else emptyList() }
 LaunchedEffect(closedCandles, selected) {
  val latest = closedCandles.lastOrNull()
  if (latest != null && latest.time != lastClosedBarTime) {
   if (lockedSignal != null) { lockBarsLeft -= 1; if (lockBarsLeft <= 0) { lockedSignal = null; lockBarsLeft = 0 } }
   if (lockedSignal == null) {
    val candidate = analyse(closedCandles)
    if (candidate != null) { lockedSignal = candidate; lockBarsLeft = candidate.expiry }
   }
   lastClosedBarTime = latest.time
  }
 }
 val signal = lockedSignal
 val backtest = remember(candles) { calculateBacktest(candles) }
 val visibleCandles = remember(candles) { candles.takeLast(60) }
 val patternMarks = remember(visibleCandles) { PatternVision.detect(visibleCandles) }
 val patternProjection = remember(visibleCandles, patternMarks) { PatternVision.project(visibleCandles, patternMarks.lastOrNull()) }
 DisposableEffect(Unit){ onDispose { streamStop?.interrupt() } }
 MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Panel,primary=Green,onBackground=White,onSurface=White)) {
  val accentRed = Color(0xFFFF3048)
  val blackPanel = Color(0xFF090B10)
  val line = Color(0xFF30333D)
  Column(Modifier.fillMaxSize().background(Color(0xFF050609)).verticalScroll(rememberScrollState()).padding(horizontal=12.dp, vertical=10.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
   // AURIX premium red/black identity
   Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
    Column {
     Text("AURIX", color=Color(0xFFE7EAF0), fontSize=34.sp, fontWeight=FontWeight.Black, letterSpacing=2.sp)
     Text("PATTERN VISION  •  QUANT ENGINE", color=Color(0xFFB6BBC6), fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.2.sp)
     Text("● LIVE MARKET ANALYTICS", color=Green, fontSize=9.sp, fontWeight=FontWeight.Bold)
    }
    Image(painterResource(com.snowflakepro.R.drawable.brand_logo), contentDescription="AURIX", modifier=Modifier.size(52.dp), contentScale=ContentScale.Fit)
   }
   Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
    listOf("АНАЛИЗ", "ГРАФИК", "ПАТТЕРНЫ", "СТАТИСТИКА", "НАСТРОЙКИ").forEachIndexed { i, label ->
     Surface(color=if(i==0) Color(0xFF351016) else blackPanel, shape=RoundedCornerShape(9.dp), border=androidx.compose.foundation.BorderStroke(1.dp, if(i==0) accentRed else line), modifier=Modifier.weight(1f)) {
      Box(Modifier.padding(vertical=10.dp), contentAlignment=Alignment.Center) { Text(label, color=if(i==0) Color.White else Muted, fontSize=8.sp, fontWeight=FontWeight.Bold, maxLines=1) }
     }
    }
   }
   Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp), verticalAlignment=Alignment.CenterVertically) {
    Box(Modifier.weight(1.3f)) {
     OutlinedButton(onClick={showMenu=true}, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(10.dp), border=androidx.compose.foundation.BorderStroke(1.dp, accentRed)) {
      Text(assets.firstOrNull{it.symbol==selected}?.name ?: "EUR/USD · ВЫБРАТЬ", color=White, fontSize=11.sp, maxLines=1)
     }
     DropdownMenu(expanded=showMenu,onDismissRequest={showMenu=false}) { assets.forEach { a -> DropdownMenuItem(text={Text(a.name+if(a.open==false)" · закрыт" else "")},onClick={selected=a.symbol;showMenu=false;busy=true;loadCandles(apiKey,a.symbol){r->busy=false;r.onSuccess{candles=it;status="Загружено ${it.size} свечей: ${a.name}"}.onFailure{status="История: ${it.message}"}}}) } }
    }
    Surface(color=Color(0xFF171B23),shape=RoundedCornerShape(9.dp),border=androidx.compose.foundation.BorderStroke(1.dp,line)) { Text("M1",Modifier.padding(horizontal=17.dp, vertical=12.dp),color=White,fontWeight=FontWeight.Bold,fontSize=12.sp) }
    Surface(color=Color(0xFF171B23),shape=RoundedCornerShape(9.dp),border=androidx.compose.foundation.BorderStroke(1.dp,accentRed)) { Text("ПРОГНОЗ · 4",Modifier.padding(horizontal=10.dp, vertical=12.dp),color=White,fontSize=10.sp,fontWeight=FontWeight.Bold) }
   }
   // Main chart card
   Surface(color=blackPanel,shape=RoundedCornerShape(14.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFF34303A))) {
    Column(Modifier.padding(10.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("${selected.ifBlank{"EUR/USD"}} · M1",color=White,fontSize=11.sp,fontWeight=FontWeight.Bold); Text(if(streamOn)"● LIVE" else "○ ОЖИДАНИЕ",color=if(streamOn)Green else Muted,fontSize=10.sp,fontWeight=FontWeight.Bold) }
     if(candles.isNotEmpty()) CandleChart(visibleCandles,Modifier.fillMaxWidth().height(280.dp),patternMarks,patternProjection)
     else Box(Modifier.fillMaxWidth().height(280.dp).background(Color(0xFF0D1118),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center) { Text("Загрузи каталог и свечи Quotex",color=Muted,fontSize=12.sp) }
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("ЦЕНА",color=Muted,fontSize=9.sp); Text(tickPrice?.toString()?:candles.lastOrNull()?.close?.toString() ?: "—",color=White,fontSize=13.sp,fontWeight=FontWeight.Bold) }
    }
   }
   // Signal + pattern blocks
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
    Surface(Modifier.weight(1f),color=Color(0xFF10150F),shape=RoundedCornerShape(13.dp),border=androidx.compose.foundation.BorderStroke(1.dp,if(signal?.direction=="PUT") Red else Color(0xFF087E51))) {
     Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
      Text("СИГНАЛ",color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold)
      Text(signal?.direction ?: "НЕТ СДЕЛКИ",color=if(signal?.direction=="PUT")Red else if(signal?.direction=="CALL")Green else White,fontSize=26.sp,fontWeight=FontWeight.Black)
      Text("Оценка условий",color=Muted,fontSize=9.sp)
      Text(signal?.let{"${it.score}/100"} ?: "—",color=Green,fontSize=22.sp,fontWeight=FontWeight.ExtraBold)
      Text(if(signal!=null)"TIME FREEZE · $lockBarsLeft свечи" else "Ожидание подтверждения",color=Muted,fontSize=9.sp)
     }
    }
    Surface(Modifier.weight(1f),color=Color(0xFF11131A),shape=RoundedCornerShape(13.dp),border=androidx.compose.foundation.BorderStroke(1.dp,accentRed.copy(alpha=.65f))) {
     Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
      Text("PATTERN VISION",color=White,fontSize=10.sp,fontWeight=FontWeight.Bold)
      Text("Найдено: ${patternMarks.size}",color=Muted,fontSize=9.sp)
      patternMarks.firstOrNull()?.let { Text(it.type.uppercase(),color=accentRed,fontSize=15.sp,fontWeight=FontWeight.ExtraBold); Text("Структура ${it.quality}/100",color=White,fontSize=10.sp) } ?: Text("Паттерн не подтверждён",color=Muted,fontSize=11.sp)
      Text(patternProjection?.let{"ПРОЕКЦИЯ ${it.direction}"} ?: "ПРОЕКЦИЯ —",color=if(patternProjection?.direction=="PUT")Red else Green,fontSize=11.sp,fontWeight=FontWeight.Bold)
     }
    }
   }
   // OHLC projection cards
   Surface(color=blackPanel,shape=RoundedCornerShape(13.dp),border=androidx.compose.foundation.BorderStroke(1.dp,Color(0xFF54232B))) {
    Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
     Text("ПРОЕКЦИЯ 4 СВЕЧЕЙ · OHLC",color=White,fontSize=12.sp,fontWeight=FontWeight.ExtraBold)
     val projected = patternProjection?.candles.orEmpty().take(4)
     if(projected.isEmpty()) Text("Недостаточно данных для расчёта проекции",color=Muted,fontSize=10.sp)
     else Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
      projected.forEach { c ->
       Surface(Modifier.weight(1f),color=Color(0xFF10141B),shape=RoundedCornerShape(8.dp),border=androidx.compose.foundation.BorderStroke(1.dp,line)) {
        Column(Modifier.padding(6.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(3.dp)) {
         Text("#${c.index}",color=Muted,fontSize=9.sp,fontWeight=FontWeight.Bold)
         Canvas(Modifier.width(28.dp).height(48.dp)) {
          val center=size.width/2; val top=5f; val bottom=size.height-5f
          val range=(c.high-c.low).coerceAtLeast(0.000001f)
          fun yy(v:Float)=bottom-(v-c.low)/range*(bottom-top)
          val col=if(c.close>=c.open)Green else Red
          drawLine(col,Offset(center,yy(c.high)),Offset(center,yy(c.low)),2.dp.toPx())
          val bodyTop=yy(max(c.open,c.close)); val bodyBottom=yy(min(c.open,c.close))
          drawRect(col,Offset(center-5.dp.toPx(),bodyTop),androidx.compose.ui.geometry.Size(10.dp.toPx(),(bodyBottom-bodyTop).coerceAtLeast(3.dp.toPx())))
         }
         Text("O ${"%.5f".format(c.open)}",color=Muted,fontSize=7.sp,maxLines=1)
         Text("H ${"%.5f".format(c.high)}",color=Green,fontSize=7.sp,maxLines=1)
         Text("L ${"%.5f".format(c.low)}",color=Red,fontSize=7.sp,maxLines=1)
         Text("C ${"%.5f".format(c.close)}",color=White,fontSize=7.sp,maxLines=1)
        }
       }
      }
     }
     Text(patternProjection?.explanation ?: "Расчётный сценарий, не гарантированный прогноз.",color=Muted,fontSize=9.sp)
    }
   }
   // Strategy diagnostics
   Surface(color=Color(0xFF10131A),shape=RoundedCornerShape(13.dp),border=androidx.compose.foundation.BorderStroke(1.dp,line)) {
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
     Text("АНАЛИЗ РЫНКА",color=White,fontSize=12.sp,fontWeight=FontWeight.ExtraBold)
     Text("Тренд и фильтры: EMA 9/21 · RSI · ATR · тело свечи · тени",color=Muted,fontSize=10.sp)
     Text(signal?.reason ?: "Ожидаем подтверждение EMA 9/21, RSI и ATR на закрытой свече.",color=White,fontSize=10.sp)
     Divider(color=line)
     Text("СТАТИСТИКА M1",color=White,fontSize=11.sp,fontWeight=FontWeight.Bold)
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
      StatCell("СДЕЛКИ",backtest.total.toString(),White,Modifier.weight(1f))
      StatCell("ПОБЕДЫ",backtest.wins.toString(),Green,Modifier.weight(1f))
      StatCell("УБЫТКИ",backtest.losses.toString(),Red,Modifier.weight(1f))
      StatCell("WIN RATE",if(backtest.total>0)"${backtest.winRate}%" else "—",Green,Modifier.weight(1f))
     }
     Text("Историческая направленная точность не равна доходности и не гарантирует будущий результат.",color=Muted,fontSize=9.sp)
    }
   }
   // Settings and live controls remain functional
   Surface(color=blackPanel,shape=RoundedCornerShape(13.dp),border=androidx.compose.foundation.BorderStroke(1.dp,line)) {
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
     Text("ПОДКЛЮЧЕНИЕ OTCHARTS · READ ONLY",color=White,fontSize=11.sp,fontWeight=FontWeight.Bold)
     OutlinedTextField(value=apiKey,onValueChange={apiKey=it.trim()},modifier=Modifier.fillMaxWidth(),label={Text("API-ключ OTCharts Lite")},singleLine=true,visualTransformation=PasswordVisualTransformation(),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=White,unfocusedTextColor=White,focusedBorderColor=accentRed,unfocusedBorderColor=line))
     Button(onClick={if(apiKey.isBlank())status="Введи API-ключ." else {busy=true;status="Загружаем каталог Quotex…";fetchAssets(apiKey){r->busy=false;r.onSuccess{list->assets=list;if(selected.isBlank()||list.none{it.symbol==selected})selected=list.firstOrNull{it.open!=false}?.symbol?:list.firstOrNull()?.symbol.orEmpty();status="Каталог получен: ${list.size} инструментов.";if(selected.isNotBlank())loadCandles(apiKey,selected){cr->cr.onSuccess{candles=it;status="История загружена: ${candles.size} свечей M1."}.onFailure{status="Ошибка истории: ${it.message}"}}}.onFailure{status="Каталог: ${it.message}"}}}},enabled=!busy,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=accentRed)) { Text(if(busy)"Загрузка…" else "ЗАГРУЗИТЬ ДАННЫЕ QUOTEX") }
     Text(status,color=Muted,fontSize=9.sp)
     Button(onClick={if(streamOn){streamStop?.interrupt();streamStop=null;streamOn=false;status="Поток остановлен."}else if(apiKey.isBlank()||assets.isEmpty()){status="Сначала введи ключ и загрузи каталог."}else{val symbols=assets.filter{it.open!=false}.take(5).joinToString(","){it.symbol};if(symbols.isBlank())status="Нет открытых инструментов." else{streamOn=true;status="Подключаем поток: $symbols";streamStop=startStream(apiKey,symbols){t->main{if(t.symbol==selected){tickPrice=t.price;lastTick=t.time.toString();candles=applyTick(candles,t)}}}}}},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(streamOn)Color(0xFF56202A) else Color(0xFF174D3A))) { Text(if(streamOn)"ОСТАНОВИТЬ LIVE STREAM" else "ЗАПУСТИТЬ LIVE STREAM") }
     Text("Источник: OTCharts — независимый read-only сервис, не официальный API Quotex. Приложение не размещает сделки.",color=Muted,fontSize=9.sp)
    }
   }
  }
 }


@Composable
private fun StatCell(label:String,value:String,valueColor:Color,modifier:Modifier=Modifier){
 Column(modifier.padding(4.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(label,color=Muted,fontSize=7.sp,fontWeight=FontWeight.Bold);Text(value,color=valueColor,fontSize=14.sp,fontWeight=FontWeight.ExtraBold)}
}

private fun fetchAssets(key:String,done:(Result<List<Asset>>)->Unit){Thread{try{val j=request("/v1/symbols?venue=quotex",key);val a=j.getJSONArray("symbols");val list=buildList{for(i in 0 until a.length()){val x=a.getJSONObject(i);add(Asset(x.getString("symbol"),x.optString("name",x.getString("symbol")),if(x.isNull("open"))null else x.optBoolean("open")))}}; main{done(Result.success(list))}}catch(e:Exception){main{done(Result.failure(e))}}}.start()}
private fun loadCandles(key:String,symbol:String,done:(Result<List<Candle>>)->Unit){Thread{try{val enc=URLEncoder.encode(symbol,"UTF-8");val j=request("/v1/candles?venue=quotex&symbol=$enc&tf=60&limit=360",key);val a=j.getJSONArray("candles");val list=buildList{for(i in 0 until a.length()){val x=a.getJSONObject(i);add(Candle(x.getDouble("open").toFloat(),x.getDouble("high").toFloat(),x.getDouble("low").toFloat(),x.getDouble("close").toFloat(),x.optLong("time")))}};main{done(Result.success(list))}}catch(e:Exception){main{done(Result.failure(e))}}}.start()}
private fun request(path:String,key:String):JSONObject{val c=URL("https://otcharts.com$path").openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=20000;c.setRequestProperty("Authorization","Bearer $key");c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","SnowflakePro/2.0 Android");val code=c.responseCode;val body=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw IllegalStateException("HTTP $code: ${body.take(240)}");return JSONObject(body)}
private fun startStream(key:String,symbols:String,onTick:(Tick)->Unit):Thread{val t=Thread{var c:HttpURLConnection?=null;try{val enc=URLEncoder.encode(symbols,"UTF-8");c=URL("https://otcharts.com/v1/stream?venue=quotex&symbol=$enc").openConnection() as HttpURLConnection;c.connectTimeout=20000;c.readTimeout=0;c.setRequestProperty("Authorization","Bearer $key");c.setRequestProperty("Accept","text/event-stream");c.setRequestProperty("Cache-Control","no-cache");c.setRequestProperty("User-Agent","SnowflakePro/2.0 Android");val code=c.responseCode;if(code !in 200..299){val msg=(c.errorStream?:c.inputStream).bufferedReader().use{it.readText()};throw IllegalStateException("Stream HTTP $code: ${msg.take(200)}")};var event="";c.inputStream.bufferedReader().useLines{lines->lines.forEach{line->if(Thread.currentThread().isInterrupted)throw InterruptedException();when{line.startsWith("event:")->event=line.substringAfter(':').trim();line.startsWith("data:")->if(event=="tick"){val j=JSONObject(line.substringAfter(':').trim());onTick(Tick(j.getString("symbol"),j.getDouble("price").toFloat(),j.optLong("time")))}}}}}catch(_:InterruptedException){}catch(_:Exception){}finally{c?.disconnect()}};t.isDaemon=true;t.start();return t}
private fun main(block:()->Unit)=Handler(Looper.getMainLooper()).post(block)
private fun applyTick(old:List<Candle>,tick:Tick):List<Candle>{if(old.isEmpty())return old;val start=(tick.time/60)*60;val last=old.last();return if(last.time==start)old.dropLast(1)+last.copy(high=max(last.high,tick.price),low=min(last.low,tick.price),close=tick.price) else if(start>last.time)old+ Candle(last.close,max(last.close,tick.price),min(last.close,tick.price),tick.price,start) else old}

private fun analyse(c:List<Candle>):Signal? {
 if(c.size<60) return null
 val closes=c.map{it.close.toDouble()}
 fun ema(period:Int):Double { val k=2.0/(period+1.0); var value=closes.take(period).average(); for(v in closes.drop(period)) value=v*k+value*(1.0-k); return value }
 val e9=ema(9); val e21=ema(21)
 val diffs=closes.zipWithNext{a,b->b-a}
 val recent=diffs.takeLast(14); val gains=recent.filter{it>0.0}.sum(); val losses=-recent.filter{it<0.0}.sum()
 val rsi=if(losses==0.0) 100.0 else 100.0-100.0/(1.0+gains/losses)
 val ranges=c.map{(it.high.toDouble()-it.low.toDouble()).coerceAtLeast(0.0)}
 val atr=ranges.takeLast(14).average(); val avgRange=ranges.takeLast(50).average()
 if(avgRange<=0.0 || atr<avgRange*0.45 || atr>avgRange*2.8) return null
 val up=e9>e21 && rsi in 53.0..67.0; val down=e9<e21 && rsi in 33.0..47.0
 if(!up&&!down) return null
 val last=c.last(); val body=abs(last.close.toDouble()-last.open.toDouble())
 if(body<atr*0.18) return null
 if(if(up) last.close<=last.open else last.close>=last.open) return null
 val upperWick=last.high.toDouble()-max(last.open,last.close).toDouble()
 val lowerWick=min(last.open,last.close).toDouble()-last.low.toDouble()
 if(if(up) upperWick>body*1.35 else lowerWick>body*1.35) return null
 val strength=abs(e9-e21)/atr
 if(strength<0.08) return null
 val score=(55.0+min(20.0,strength*18.0)+min(15.0,body/atr*12.0)).toInt().coerceIn(55,85)
 val expiry=when { atr>avgRange*1.55->1; strength>0.30->2; else->3 }
 return Signal(if(up)"CALL" else "PUT",score,expiry,"EMA 9/21, RSI ${rsi.toInt()}, ATR, тело свечи и встречная тень прошли фильтры.")
}

private fun calculateBacktest(c:List<Candle>):BacktestStats {
 if(c.size<90) return BacktestStats(0,0,0)
 var wins=0; var losses=0; var ties=0
 val start=max(60,c.size-300)
 for(i in start until c.size-4) {
  val sig=analyse(c.subList(0,i)) ?: continue
  val entry=c[i].open.toDouble()
  val exitIndex=i+sig.expiry-1
  if(exitIndex>c.lastIndex) continue
  val exit=c[exitIndex].close.toDouble()
  when { abs(exit-entry)<1e-10 -> ties++; sig.direction=="CALL" && exit>entry -> wins++; sig.direction=="PUT" && exit<entry -> wins++; else -> losses++ }
 }
 return BacktestStats(wins,losses,ties)
}



@Composable
private fun CandleChart(data: List<Candle>, modifier: Modifier = Modifier, marks: List<PatternMark> = emptyList(), projection: PatternProjection? = null) {
    Canvas(
        modifier
            .background(Color(0xFF0D1520), RoundedCornerShape(10.dp))
            .padding(5.dp)
    ) {
        if (data.isEmpty()) return@Canvas

        val projected = projection?.candles.orEmpty().take(4)
        val low = min(data.minOf { it.low }, projected.minOfOrNull { it.low } ?: data.minOf { it.low })
        val high = max(data.maxOf { it.high }, projected.maxOfOrNull { it.high } ?: data.maxOf { it.high })
        val padding = (high - low).coerceAtLeast(0.000001f) * 0.08f
        val minPrice = low - padding
        val maxPrice = high + padding
        val priceRange = (maxPrice - minPrice).coerceAtLeast(0.000001f)
        fun y(price: Float): Float = size.height - (price - minPrice) / priceRange * size.height

        for (i in 0..4) {
            val yy = size.height * i / 4f
            drawLine(Grid, Offset(0f, yy), Offset(size.width, yy), 1f)
        }

        // Reserve a clearly visible 25% of the chart for the four projected candles.
        // Historical candles occupy 75%; projected candles get their own wider slots.
        val historyWidth = if (projected.isNotEmpty()) size.width * 0.75f else size.width
        val historySlot = historyWidth / data.size.toFloat()
        val futureWidth = size.width - historyWidth
        val futureSlot = if (projected.isNotEmpty()) futureWidth / 4f else historySlot

        data.forEachIndexed { index, candle ->
            val x = (index + 0.5f) * historySlot
            val candleColor = if (candle.close >= candle.open) Green else Red
            drawLine(candleColor, Offset(x, y(candle.high)), Offset(x, y(candle.low)), 2f)
            val bodyTop = y(max(candle.open, candle.close))
            val bodyBottom = y(min(candle.open, candle.close))
            val bodyWidth = (historySlot * 0.58f).coerceAtLeast(2f)
            drawRect(candleColor, Offset(x - bodyWidth / 2f, bodyTop),
                androidx.compose.ui.geometry.Size(bodyWidth, max(3f, bodyBottom - bodyTop)))
        }

        // Pattern boundaries are anchored only to the historical-price region.
        marks.forEach { mark ->
            val left = (mark.startIndex.coerceIn(0, data.lastIndex) + 0.5f) * historySlot
            val right = (mark.endIndex.coerceIn(0, data.lastIndex) + 0.5f) * historySlot
            val lineColor = when (mark.direction) { "CALL" -> Green; "PUT" -> Red; else -> Color(0xFFFFC642) }
            val dash = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 5f))
            drawLine(lineColor, Offset(left, y(mark.upper)), Offset(right, y(mark.upper)), 2f, pathEffect = dash)
            drawLine(lineColor, Offset(left, y(mark.lower)), Offset(right, y(mark.lower)), 2f, pathEffect = dash)
        }

        if (projected.isNotEmpty()) {
            val separatorX = historyWidth
            drawLine(Color(0xFF64748B).copy(alpha = 0.75f), Offset(separatorX, 0f), Offset(separatorX, size.height), 1.5f,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 5f)))
            projected.forEachIndexed { index, candle ->
                val x = historyWidth + (index + 0.5f) * futureSlot
                val bullish = candle.close >= candle.open
                val candleColor = if (bullish) Green else Red
                val wickWidth = 2.5f
                // Full OHLC wick: high-to-low, with a solid, clearly visible body.
                drawLine(candleColor, Offset(x, y(candle.high)), Offset(x, y(candle.low)), wickWidth)
                val bodyTop = y(max(candle.open, candle.close))
                val bodyBottom = y(min(candle.open, candle.close))
                val bodyWidth = (futureSlot * 0.52f).coerceAtLeast(7f)
                val bodyHeight = max(5f, bodyBottom - bodyTop)
                drawRect(candleColor.copy(alpha = 0.88f), Offset(x - bodyWidth / 2f, bodyTop),
                    androidx.compose.ui.geometry.Size(bodyWidth, bodyHeight))
                // Tiny OHLC tick marks make open/close orientation readable at a glance.
                val tick = bodyWidth * 0.22f
                drawLine(candleColor, Offset(x - tick, y(candle.open)), Offset(x, y(candle.open)), 1.5f)
                drawLine(candleColor, Offset(x, y(candle.close)), Offset(x + tick, y(candle.close)), 1.5f)
            }
        }
    }
}
