package com.snowflakepro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

data class Candle(val open: Float, val high: Float, val low: Float, val close: Float, val time: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FutureVisionApp() }
    }
}
