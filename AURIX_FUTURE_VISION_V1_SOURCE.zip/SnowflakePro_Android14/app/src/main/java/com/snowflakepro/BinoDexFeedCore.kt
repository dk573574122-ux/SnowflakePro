package com.snowflakepro

import org.json.JSONArray
import org.json.JSONObject

/** Parsed public market quote from the BinoDex Socket.IO graphic namespace. */
data class BinoDexQuote(
    val symbol: String,
    val price: Double,
    val serverTimestampMs: Long,
    val receivedWallClockMs: Long,
    val receivedMonotonicNs: Long
)

data class BinoDexTimePing(val serverTimestampMs: Long?)

data class FeedTiming(
    val estimatedServerOffsetMs: Long?,
    val apparentTransitMs: Long?,
    val monotonicElapsedMs: Long,
    val note: String
)

/**
 * Parser for the observed Socket.IO Engine.IO message shapes.
 * It deliberately does not contain credentials, a guessed host URL, or a connection routine.
 * Only the message shapes visible in the user's DevTools screenshots are accepted.
 */
object BinoDexSocketParser {
    fun parse(packet: String, receivedWallClockMs: Long, receivedMonotonicNs: Long): Any? {
        val trimmed = packet.trim()
        if (trimmed == "2") return "PING"
        if (trimmed == "3") return "PONG"
        if (trimmed.startsWith("42/graphic,0[\"time_ping\"]")) return BinoDexTimePing(null)
        if (trimmed.startsWith("43/graphic,0[")) {
            val raw = trimmed.substringAfter("43/graphic,0[").substringBeforeLast("]").trim()
            return BinoDexTimePing(raw.toLongOrNull())
        }
        if (!trimmed.startsWith("42/graphic,")) return null

        val jsonText = trimmed.substringAfter("42/graphic,").trim()
        val payload = JSONArray(jsonText)
        if (payload.length() < 2 || payload.optString(0) != "graphic") return null
        val quote = payload.optJSONObject(1) ?: return null
        val symbol = quote.optString("symbol").takeIf { it.isNotBlank() } ?: return null
        val price = quote.optDouble("price", Double.NaN)
        val timestamp = quote.optLong("timestamp", -1L)
        if (!price.isFinite() || price <= 0.0 || timestamp <= 0L) return null
        return BinoDexQuote(symbol, price, timestamp, receivedWallClockMs, receivedMonotonicNs)
    }
}

/** Estimates clock offset from a server time sample. Transit is only an approximation unless
 * the protocol provides a true server-send timestamp and a measured RTT midpoint. */
class ServerClockEstimator {
    private var offsetMs: Long? = null
    private var lastSampleMonoNs: Long? = null

    @Synchronized fun addServerTimeSample(serverTimeMs: Long, receivedWallMs: Long, receivedMonoNs: Long) {
        val sampleOffset = serverTimeMs - receivedWallMs
        offsetMs = offsetMs?.let { (it * 3L + sampleOffset) / 4L } ?: sampleOffset
        lastSampleMonoNs = receivedMonoNs
    }

    @Synchronized fun evaluate(quote: BinoDexQuote): FeedTiming {
        val offset = offsetMs
        val correctedLocalAtReceive = quote.receivedWallClockMs + (offset ?: 0L)
        val apparent = if (offset != null) correctedLocalAtReceive - quote.serverTimestampMs else null
        val elapsed = lastSampleMonoNs?.let { ((quote.receivedMonotonicNs - it) / 1_000_000L).coerceAtLeast(0L) } ?: 0L
        val note = when {
            offset == null -> "Нет серверного образца времени; задержка не вычислена"
            apparent!! < -2_000L -> "Timestamp заметно опережает скорректированное время; проверить единицы и синхронизацию"
            apparent > 10_000L -> "Большая задержка или устаревшая котировка"
            else -> "Временная метка в ожидаемом диапазоне; это не доказательство будущих данных"
        }
        return FeedTiming(offset, apparent, elapsed, note)
    }
}

/** Builds time-bucket OHLC candles from quote ticks; interval is milliseconds. */
class TickCandleBuilder(private val intervalMs: Long) {
    init { require(intervalMs > 0L) }
    private val completed = ArrayList<Candle>()
    private var active: Candle? = null

    @Synchronized fun add(quote: BinoDexQuote): List<Candle> {
        val bucket = (quote.serverTimestampMs / intervalMs) * intervalMs
        val price = quote.price.toFloat()
        val current = active
        if (current == null) {
            active = Candle(price, price, price, price, bucket)
        } else if (bucket == current.time) {
            active = current.copy(high = maxOf(current.high, price), low = minOf(current.low, price), close = price)
        } else if (bucket > current.time) {
            completed.add(current)
            active = Candle(current.close, maxOf(current.close, price), minOf(current.close, price), price, bucket)
        }
        return snapshot()
    }

    @Synchronized fun snapshot(): List<Candle> = completed.toList() + listOfNotNull(active)
}
