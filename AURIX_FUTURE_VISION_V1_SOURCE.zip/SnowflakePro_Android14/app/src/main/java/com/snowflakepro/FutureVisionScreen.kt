package com.snowflakepro

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val FVBg = Color(0xFF050609)
private val FVPanel = Color(0xFF11141B)
private val FVLine = Color(0xFF30333D)
private val FVGreen = Color(0xFF20C997)
private val FVRed = Color(0xFFFF3048)
private val FVMuted = Color(0xFF929BAA)

@Composable
fun FutureVisionApp() {
    var selectedSymbol by remember { mutableStateOf("BTC-OTC") }
    var feedState by remember { mutableStateOf("Ожидание подключения") }
    var latestPrice by remember { mutableStateOf("—") }
    var serverTime by remember { mutableStateOf("—") }
    var receiveTime by remember { mutableStateOf("—") }
    var timingNote by remember { mutableStateOf("Нет записанных котировок") }
    var candleCount by remember { mutableIntStateOf(0) }

    MaterialTheme(colorScheme = darkColorScheme(background = FVBg, surface = FVPanel, primary = FVGreen)) {
        Column(
            Modifier.fillMaxSize().background(FVBg).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column {
                Text("AURIX", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("FUTURE VISION  •  CANDLE INTELLIGENCE", color = FVGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text("BinoDex · READ ONLY · NO AUTO TRADING", color = FVMuted, fontSize = 9.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoCard("ИНСТРУМЕНТ", selectedSymbol, Modifier.weight(1f))
                InfoCard("ПОТОК", feedState, Modifier.weight(1f))
            }
            InfoCard("ПОСЛЕДНЯЯ ЦЕНА", latestPrice, Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoCard("SERVER TIMESTAMP", serverTime, Modifier.weight(1f))
                InfoCard("RECEIVED AT", receiveTime, Modifier.weight(1f))
            }
            InfoCard("TIMESTAMP INTELLIGENCE", timingNote, Modifier.fillMaxWidth())
            InfoCard("CANDLE MATH ENGINE", "OHLC свечи: $candleCount\nПостроение из тиков по серверному timestamp", Modifier.fillMaxWidth())
            Surface(color = FVPanel, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, FVLine)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("AI SIGNAL ENGINE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("НЕТ СДЕЛКИ", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("Сигналы появятся после получения и проверки достаточной истории свечей.", color = FVMuted, fontSize = 11.sp)
                }
            }
            Surface(color = FVPanel, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, FVRed.copy(alpha = .55f))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("ПОДКЛЮЧЕНИЕ BINODEX", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Формат пакетов /graphic частично разобран по DevTools. Для live-подключения нужны подтверждённый WebSocket URL, правила авторизации и разрешение BinoDex на сторонний read-only клиент.", color = FVMuted, fontSize = 10.sp)
                    Text("Сессионные cookies и sid не запрашиваются и не сохраняются.", color = FVGreen, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("Прогнозы являются оценками, а не известными будущими котировками.", color = FVMuted, fontSize = 9.sp)
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = FVPanel, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, FVLine)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = FVMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
